<?php
ob_start();
session_start();
if(!(isset($_SESSION['user']))){
    header('Location: /');
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Ping Server</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="css/theme.css" />
  </head>
  <body >
    <div class="container">
    <h1>Ping Server | <a href="logout.php">Logout</a></h1>
  	<hr>
	<div class="row">
      <div class="col-md-8">
        <form class="form-horizontal" role="form" method="POST">
          <p>
            <label>Server:</label>
            <input class="form-control" type="text" name="server" value="127.0.0.1">
          </p>
          <input type="submit" class="btn btn-primary" value="Ping Server">
          <input type="reset" class="btn btn-default" value="Cancel">
        </form>
      </div>

      <div class="col-md-8">
        <p>
        <pre>
            <?php
            if (($_SERVER['REQUEST_METHOD'] == 'POST')){
              if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
                $os = "WIN";
                } else {
                $os = "LINUX";
              }
            
              $server = $_POST['server'];
              
              if ($os = "WIN"){
              $cmd = "ping -n 2 ".$server;
              }else{
                $cmd = "ping -c 2 ".$server;
              }
              system($cmd);
            }   
            ?>
        </pre>    
        </p>
      </div>
  </div>

 <hr>
    <!--scripts loaded here-->
    
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    © Appsecco 2019
    <script src="js/scripts.js"></script>
  </body>
</html>